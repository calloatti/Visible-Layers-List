﻿using HarmonyLib;
using System.Collections.Generic;
using Timberborn.BlockObjectPickingSystem;
using Timberborn.BlueprintSystem;
using Timberborn.Common;
using Timberborn.Coordinates;
using Timberborn.LevelVisibilitySystem;
using Timberborn.Rendering;
using Timberborn.TerrainQueryingSystem;
using Timberborn.TerrainSystem;
using Timberborn.TerrainSystemRendering;
using UnityEngine;

namespace TimberbornLayerMod
{
  public static class VisibilityState
  {
    public static int CurrentMaxVisibleLevel = 999;
    public static TerrainMeshManager TMMInstance;
    public static ITerrainService TerrainService;
    public static Mesh WarningMesh;
    public static Material WarningMaterial;
    public static HashSet<Vector3Int> DecapitatedBlocks = new HashSet<Vector3Int>();
    public static List<Matrix4x4> WarningMatrices = new List<Matrix4x4>();
    public static bool MatricesNeedUpdate = false;
  }

  [HarmonyPatch(typeof(TerrainMeshManager), nameof(TerrainMeshManager.Load))]
  public static class Patch_TerrainMeshManager_Load
  {
    public static void Postfix(TerrainMeshManager __instance)
    {
      VisibilityState.TMMInstance = __instance;
      VisibilityState.TerrainService = AccessTools.Field(typeof(TerrainMeshManager), "_terrainService").GetValue(__instance) as ITerrainService;
    }
  }

  [HarmonyPatch(typeof(LevelVisibilityService), nameof(LevelVisibilityService.PostLoad))]
  public static class Patch_LevelVisibility_PostLoad
  {
    public static void Postfix(LevelVisibilityService __instance)
    {
      VisibilityState.CurrentMaxVisibleLevel = __instance.MaxVisibleLevel;
      VisibilityState.DecapitatedBlocks.Clear();
      VisibilityState.WarningMatrices.Clear();
      VisibilityState.MatricesNeedUpdate = true;
    }
  }

  // PATCH 1: Sync Fix - Prevents Skybox holes during layer transitions
  [HarmonyPatch(typeof(LevelVisibilityService), "InternalSetMaxVisibleLevel")]
  public static class Patch_LevelVisibility_Shaders
  {
    public static void Postfix(LevelVisibilityService __instance, int newMaxVisibleLevel)
    {
      if (VisibilityState.CurrentMaxVisibleLevel != newMaxVisibleLevel)
      {
        int oldLevel = VisibilityState.CurrentMaxVisibleLevel;
        VisibilityState.CurrentMaxVisibleLevel = newMaxVisibleLevel;
        VisibilityState.DecapitatedBlocks.Clear();
        VisibilityState.MatricesNeedUpdate = true;

        InvalidateSpecificLayers(oldLevel, newMaxVisibleLevel);

        // Uses the 0.84f cushion to ensure the floor is ready before clipping
        Shader.SetGlobalFloat("_MaxVisibleLevel", newMaxVisibleLevel - 0.84f);
      }
    }

    private static void InvalidateSpecificLayers(int oldLevel, int newLevel)
    {
      if (VisibilityState.TMMInstance == null || VisibilityState.TerrainService == null) return;
      var dirtyCodes = AccessTools.Field(typeof(TerrainMeshManager), "_dirtyCodes").GetValue(VisibilityState.TMMInstance) as HashSet<Vector3Int>;
      var invalidTiles = AccessTools.Field(typeof(TerrainMeshManager), "_invalidTiles").GetValue(VisibilityState.TMMInstance) as HashSet<Vector3Int>;
      if (dirtyCodes == null || invalidTiles == null) return;

      Vector3Int size = VisibilityState.TerrainService.Size;
      int safeOld = Mathf.Clamp(oldLevel, -2, size.z);
      int safeNew = Mathf.Clamp(newLevel, -2, size.z);
      int minZ = Mathf.Min(safeOld, safeNew);
      int maxZ = Mathf.Max(safeOld, safeNew);

      for (int z = minZ; z <= maxZ; z++)
      {
        for (int y = -1; y <= size.y; y++)
        {
          for (int x = -1; x <= size.x; x++)
          {
            dirtyCodes.Add(new Vector3Int(x, y, z));
          }
        }
      }

      int tileMinZ = Mathf.Clamp(minZ, 0, size.z - 1);
      int tileMaxZ = Mathf.Clamp(maxZ, 0, size.z - 1);
      for (int z = tileMinZ; z <= tileMaxZ; z++)
      {
        for (int y = 0; y < size.y; y++)
        {
          for (int x = 0; x < size.x; x++)
          {
            invalidTiles.Add(WorldTiling.CoordinatesToTileIndex3D(new Vector3Int(x, y, z)));
          }
        }
      }
    }
  }

  // PATCH 2: Decapitate vertical walls
  [HarmonyPatch(typeof(TerrainMeshManager), "UpdateCodeForCoords")]
  public static class Patch_TerrainMesh_NoMoreWalls
  {
    public static void Postfix(Vector3Int coords, byte[,,] ____surfaceShapeCodes)
    {
      if (coords.z > VisibilityState.CurrentMaxVisibleLevel)
      {
        ____surfaceShapeCodes[coords.x + 1, coords.y + 1, coords.z + 2] = 0;
        return;
      }
      if (coords.z != VisibilityState.CurrentMaxVisibleLevel) return;

      bool isUnderground = VisibilityState.TerrainService != null && VisibilityState.TerrainService.Underground(coords);
      if (isUnderground)
      {
        VisibilityState.DecapitatedBlocks.Add(coords);
      }
      else
      {
        VisibilityState.DecapitatedBlocks.Remove(coords);
      }
      VisibilityState.MatricesNeedUpdate = true;

      byte b = ____surfaceShapeCodes[coords.x + 1, coords.y + 1, coords.z + 2];
      ____surfaceShapeCodes[coords.x + 1, coords.y + 1, coords.z + 2] = (byte)(b & 0x55);
    }
  }

  // PATCH 3: Texture and Render Queue (FIX: Inverted Stripes)
  [HarmonyPatch(typeof(TerrainHighlightingService), nameof(TerrainHighlightingService.Load))]
  public static class Patch_Highlighting_Load
  {
    public static void Postfix(TerrainHighlightingService __instance)
    {
      AccessTools.Field(typeof(TerrainHighlightingService), "StumpMarkerOffset").SetValue(null, Vector3.zero);

      var markerFactory = AccessTools.Field(typeof(TerrainHighlightingService), "_meshDrawerFactory").GetValue(__instance) as MarkerDrawerFactory;
      if (markerFactory != null)
      {
        var specService = AccessTools.Field(typeof(MarkerDrawerFactory), "_specService").GetValue(markerFactory) as ISpecService;
        if (specService != null)
        {
          var boundsSpec = specService.GetSingleSpec<Timberborn.AreaSelectionSystem.RectangleBoundsDrawerFactorySpec>();
          VisibilityState.WarningMesh = boundsSpec.BlockBottomMesh.Asset;
          VisibilityState.WarningMaterial = new Material(boundsSpec.BlockBottomMaterial.Asset);

          // Background priority for transparency
          VisibilityState.WarningMaterial.renderQueue = 2900;
          VisibilityState.WarningMaterial.enableInstancing = true;

          Texture2D stripes = CreateProceduralStoneStripes();
          VisibilityState.WarningMaterial.SetTexture("_BaseMap", stripes);
          VisibilityState.WarningMaterial.SetTexture("_MainTex", stripes);
          VisibilityState.WarningMaterial.SetColor("_BaseColor", Color.white);
        }
      }
    }

    private static Texture2D CreateProceduralStoneStripes()
    {
      int size = 96;
      Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, true);
      tex.wrapMode = TextureWrapMode.Repeat;
      tex.filterMode = FilterMode.Trilinear;
      tex.anisoLevel = 16;

      for (int y = 0; y < size; y++)
      {
        for (int x = 0; x < size; x++)
        {
          // ADDED + 8 PIXEL SHIFT HERE
          if ((x - y + size + 8) % 32 >= 16)
          {
            float noise = Mathf.PerlinNoise(x * 0.1f, y * 0.1f);
            float r = Mathf.Lerp(0.18f, 0.28f, noise);
            float g = Mathf.Lerp(0.14f, 0.24f, noise);
            float b = Mathf.Lerp(0.10f, 0.20f, noise);

            tex.SetPixel(x, y, new Color(r, g, b, 0.9f));
          }
          else
          {
            tex.SetPixel(x, y, new Color(0.18f, 0.14f, 0.10f, 0.0f));
          }
        }
      }
      tex.Apply(true);
      return tex;
    }
  }

  [HarmonyPatch(typeof(TerrainTopMeshService), nameof(TerrainTopMeshService.OnMaxVisibleTerrainLevelChanged))]
  public static class Patch_TerrainTopMeshService_HideCap
  {
    public static bool Prefix() => false;
  }

  [HarmonyPatch(typeof(TerrainHighlightingService), nameof(TerrainHighlightingService.LateUpdateSingleton))]
  public static class Patch_Highlighting_DrawWarnings
  {
    public static void Postfix()
    {
      if (VisibilityState.WarningMesh == null || VisibilityState.WarningMaterial == null) return;

      if (VisibilityState.MatricesNeedUpdate)
      {
        VisibilityState.WarningMatrices.Clear();
        foreach (var coord in VisibilityState.DecapitatedBlocks)
        {
          Vector3 pos = CoordinateSystem.GridToWorldCentered(coord) + new Vector3(0f, 0.02f, 0f);
          VisibilityState.WarningMatrices.Add(Matrix4x4.TRS(pos, Quaternion.identity, Vector3.one));
        }
        VisibilityState.MatricesNeedUpdate = false;
      }

      int batchSize = 1000;
      for (int i = 0; i < VisibilityState.WarningMatrices.Count; i += batchSize)
      {
        int count = Mathf.Min(batchSize, VisibilityState.WarningMatrices.Count - i);
        var batch = VisibilityState.WarningMatrices.GetRange(i, count);
        Graphics.DrawMeshInstanced(VisibilityState.WarningMesh, 0, VisibilityState.WarningMaterial, batch, null, UnityEngine.Rendering.ShadowCastingMode.Off, false);
      }
    }
  }

  [HarmonyPatch]
  public static class Patch_Raycasters_IgnoreStump
  {
    public static IEnumerable<System.Reflection.MethodBase> TargetMethods()
    {
      yield return AccessTools.Method(typeof(TerrainPicker), "IsTerrainVoxelIncludeTerrainStump");
      yield return AccessTools.Method(typeof(BlockObjectPreviewPicker), "IsTerrainWithStump");
      yield return AccessTools.Method(typeof(BlockObjectPreviewPicker), "IsTerrainOrUnfinishedTerrain");
    }
    public static void Postfix(Vector3Int __0, ref bool __result)
    {
      if (__result && __0.z == VisibilityState.CurrentMaxVisibleLevel) __result = false;
    }
  }

  [HarmonyPatch(typeof(Timberborn.BlockObjectModelSystem.GameObjectExtensions), nameof(Timberborn.BlockObjectModelSystem.GameObjectExtensions.ToggleModelVisibility))]
  public static class Patch_DisableGhostShadows
  {
    public static void Prefix(ref bool showModel, ref bool showShadows)
    {
      if (!showModel) showShadows = false;
    }
  }

  [HarmonyPatch(typeof(Timberborn.BlockObjectModelSystem.BlockObjectModel), nameof(Timberborn.BlockObjectModelSystem.BlockObjectModel.UpdateModelVisibility))]
  public static class Patch_BlockObjectModel_LowerDecal
  {
    private static readonly System.Reflection.FieldInfo UndergroundModelField = AccessTools.Field(typeof(Timberborn.BlockObjectModelSystem.BlockObjectModel), "_undergroundModel");
    private static readonly System.Reflection.FieldInfo ControllerField = AccessTools.Field(typeof(Timberborn.BlockObjectModelSystem.BlockObjectModel), "_blockObjectModelController");

    public static void Postfix(Timberborn.BlockObjectModelSystem.BlockObjectModel __instance)
    {
      GameObject undergroundModel = UndergroundModelField.GetValue(__instance) as GameObject;
      if (undergroundModel != null && undergroundModel.activeSelf)
      {
        var controller = ControllerField.GetValue(__instance) as Timberborn.BlockObjectModelSystem.BlockObjectModelController;
        if (controller != null)
        {
          Vector3 currentPos = undergroundModel.transform.localPosition;
          undergroundModel.transform.localPosition = new Vector3(currentPos.x, controller.UndergroundModelZOffset - 0.830f, currentPos.z);
        }
      }
    }
  }
}